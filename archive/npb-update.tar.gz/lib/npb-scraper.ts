/**
 * NPB公式サイトからの試合日程・結果スクレイピングシステム
 * 
 * 機能:
 * - 試合日程の取得
 * - 試合結果の取得
 * - リアルタイムスコア更新
 * - データ検証・正規化
 */

import { JSDOM } from 'jsdom';

export interface GameData {
  game_id: string;
  date: string;
  league: 'central' | 'pacific' | 'interleague';
  away_team: string;
  home_team: string;
  away_score?: number;
  home_score?: number;
  status: 'scheduled' | 'live' | 'final' | 'postponed' | 'cancelled';
  inning?: number;
  venue?: string;
  start_time_jst?: string;
  links?: {
    box_score?: string;
    play_by_play?: string;
  };
  updated_at: string;
}

export interface ScrapingOptions {
  year: number;
  month?: number;
  league?: 'first' | 'farm' | 'both';
  includeDetails?: boolean;
  retryAttempts?: number;
  delayMs?: number;
}

// チーム名正規化辞書
const TEAM_NAME_MAP: Record<string, string> = {
  '巨人': 'YG',
  '阪神': 'T',
  '中日': 'D', 
  '広島': 'C',
  'ヤクルト': 'S',
  'ＤｅＮＡ': 'DB',
  'DeNA': 'DB',
  'ソフトバンク': 'H',
  '日本ハム': 'F',
  '西武': 'L',
  'ロッテ': 'M',
  'オリックス': 'B',
  '楽天': 'E'
};

export class NPBScraper {
  private baseUrl = 'https://npb.jp';
  private userAgent = 'Mozilla/5.0 (compatible; NPB-Analytics/1.0)';
  private delayMs: number;
  private retryAttempts: number;

  constructor(options: { delayMs?: number; retryAttempts?: number } = {}) {
    this.delayMs = options.delayMs || 2000; // 2秒間隔（礼儀正しいアクセス）
    this.retryAttempts = options.retryAttempts || 3;
  }

  /**
   * 指定月の試合日程を取得
   */
  async fetchMonthSchedule(options: ScrapingOptions): Promise<GameData[]> {
    const { year, month, league = 'first' } = options;
    
    if (!month) {
      throw new Error('Month is required for schedule fetching');
    }

    const urls = this.buildScheduleUrls(year, month, league);
    const allGames: GameData[] = [];

    for (const url of urls) {
      try {
        console.log(`Fetching schedule from: ${url}`);
        const games = await this.scrapeSchedulePage(url, year, month);
        allGames.push(...games);
        
        // 礼儀正しいアクセス - 間隔を開ける
        await this.delay(this.delayMs);
      } catch (error) {
        console.error(`Failed to fetch from ${url}:`, error);
      }
    }

    return this.deduplicateGames(allGames);
  }

  /**
   * 今日の試合を取得（リアルタイム更新用）
   */
  async fetchTodayGames(): Promise<GameData[]> {
    const today = new Date();
    const year = today.getFullYear();
    const month = today.getMonth() + 1;
    
    const allGames = await this.fetchMonthSchedule({ year, month });
    const todayStr = today.toISOString().split('T')[0];
    
    return allGames.filter(game => game.date === todayStr);
  }

  /**
   * 進行中の試合のスコア更新
   */
  async updateLiveGames(games: GameData[]): Promise<GameData[]> {
    const liveGames = games.filter(game => game.status === 'live');
    const updatedGames: GameData[] = [];

    for (const game of liveGames) {
      try {
        const updatedGame = await this.fetchGameDetails(game);
        updatedGames.push(updatedGame);
        await this.delay(this.delayMs);
      } catch (error) {
        console.error(`Failed to update game ${game.game_id}:`, error);
        updatedGames.push(game); // 元のデータを保持
      }
    }

    return updatedGames;
  }

  /**
   * スケジュールページのURL構築
   */
  private buildScheduleUrls(year: number, month: number, league: string): string[] {
    const monthStr = month.toString().padStart(2, '0');
    const urls: string[] = [];

    if (league === 'first' || league === 'both') {
      urls.push(`${this.baseUrl}/games/${year}/schedule_${monthStr}_detail.html`);
    }
    
    if (league === 'farm' || league === 'both') {
      urls.push(`${this.baseUrl}/farm/${year}/schedule_${monthStr}_detail.html`);
    }

    return urls;
  }

  /**
   * スケジュールページのスクレイピング
   */
  private async scrapeSchedulePage(url: string, year: number, month: number): Promise<GameData[]> {
    const html = await this.fetchWithRetry(url);
    const dom = new JSDOM(html);
    const document = dom.window.document;
    
    const games: GameData[] = [];
    
    // NPB公式サイトの構造に合わせてセレクターを調整
    const gameElements = document.querySelectorAll('.schedule-game-detail, .game-item');
    
    for (const element of gameElements) {
      try {
        const game = this.parseGameElement(element as Element, year, month);
        if (game) {
          games.push(game);
        }
      } catch (error) {
        console.warn('Failed to parse game element:', error);
      }
    }

    return games;
  }

  /**
   * ゲーム要素のパース
   */
  private parseGameElement(element: Element, year: number, month: number): GameData | null {
    try {
      // 日付の取得
      const dateElement = element.querySelector('.date, .game-date');
      if (!dateElement) return null;
      
      const dateText = dateElement.textContent?.trim();
      if (!dateText) return null;
      
      const date = this.parseDate(dateText, year, month);
      
      // チーム名の取得
      const awayTeamElement = element.querySelector('.away-team, .visitor');
      const homeTeamElement = element.querySelector('.home-team, .home');
      
      if (!awayTeamElement || !homeTeamElement) return null;
      
      const awayTeam = this.normalizeTeamName(awayTeamElement.textContent?.trim() || '');
      const homeTeam = this.normalizeTeamName(homeTeamElement.textContent?.trim() || '');
      
      if (!awayTeam || !homeTeam) return null;

      // スコアの取得
      const awayScoreElement = element.querySelector('.away-score, .visitor-score');
      const homeScoreElement = element.querySelector('.home-score, .home-score');
      
      const awayScore = awayScoreElement ? parseInt(awayScoreElement.textContent?.trim() || '') : undefined;
      const homeScore = homeScoreElement ? parseInt(homeScoreElement.textContent?.trim() || '') : undefined;

      // 試合状況の判定
      let status: GameData['status'] = 'scheduled';
      if (awayScore !== undefined && homeScore !== undefined) {
        status = 'final';
      } else if (element.classList.contains('live')) {
        status = 'live';
      }

      // ゲームIDの生成
      const game_id = this.generateGameId(date, awayTeam, homeTeam);

      // 球場・開始時間の取得
      const venueElement = element.querySelector('.venue, .stadium');
      const venue = venueElement?.textContent?.trim();

      const timeElement = element.querySelector('.start-time, .game-time');
      const start_time_jst = timeElement?.textContent?.trim();

      return {
        game_id,
        date,
        league: this.determineLeague(awayTeam, homeTeam),
        away_team: awayTeam,
        home_team: homeTeam,
        away_score: awayScore,
        home_score: homeScore,
        status,
        venue,
        start_time_jst,
        updated_at: new Date().toISOString()
      };
    } catch (error) {
      console.error('Error parsing game element:', error);
      return null;
    }
  }

  /**
   * 日付文字列のパース
   */
  private parseDate(dateText: string, year: number, month: number): string {
    // "3/15" のような形式を想定
    const match = dateText.match(/(\d{1,2})\/(\d{1,2})/);
    if (match) {
      const parsedMonth = parseInt(match[1]);
      const day = parseInt(match[2]);
      return `${year}-${parsedMonth.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
    }
    
    // その他のフォーマットに対応
    return `${year}-${month.toString().padStart(2, '0')}-01`; // フォールバック
  }

  /**
   * チーム名の正規化
   */
  private normalizeTeamName(teamName: string): string {
    const cleaned = teamName.replace(/\s+/g, '').trim();
    return TEAM_NAME_MAP[cleaned] || cleaned;
  }

  /**
   * リーグの判定
   */
  private determineLeague(awayTeam: string, homeTeam: string): 'central' | 'pacific' | 'interleague' {
    const centralTeams = ['YG', 'T', 'D', 'C', 'S', 'DB'];
    const pacificTeams = ['H', 'F', 'L', 'M', 'B', 'E'];
    
    const awayIsCentral = centralTeams.includes(awayTeam);
    const homeIsCentral = centralTeams.includes(homeTeam);
    const awayIsPacific = pacificTeams.includes(awayTeam);
    const homeIsPacific = pacificTeams.includes(homeTeam);

    if (awayIsCentral && homeIsCentral) return 'central';
    if (awayIsPacific && homeIsPacific) return 'pacific';
    return 'interleague';
  }

  /**
   * ゲームIDの生成
   */
  private generateGameId(date: string, awayTeam: string, homeTeam: string): string {
    const dateStr = date.replace(/-/g, '');
    return `${dateStr}_${awayTeam}_${homeTeam}`;
  }

  /**
   * 試合詳細の取得
   */
  private async fetchGameDetails(game: GameData): Promise<GameData> {
    // 詳細ページからスコア更新などを実装
    // 今回は簡略化してそのまま返す
    return {
      ...game,
      updated_at: new Date().toISOString()
    };
  }

  /**
   * 重複削除
   */
  private deduplicateGames(games: GameData[]): GameData[] {
    const seen = new Set<string>();
    return games.filter(game => {
      if (seen.has(game.game_id)) {
        return false;
      }
      seen.add(game.game_id);
      return true;
    });
  }

  /**
   * HTTP取得（リトライ付き）
   */
  private async fetchWithRetry(url: string): Promise<string> {
    for (let attempt = 1; attempt <= this.retryAttempts; attempt++) {
      try {
        const response = await fetch(url, {
          headers: {
            'User-Agent': this.userAgent,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'ja,en-US;q=0.7,en;q=0.3',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
          }
        });

        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

        return await response.text();
      } catch (error) {
        console.warn(`Attempt ${attempt}/${this.retryAttempts} failed for ${url}:`, error);
        
        if (attempt === this.retryAttempts) {
          throw error;
        }
        
        // 指数バックオフで再試行
        await this.delay(this.delayMs * Math.pow(2, attempt - 1));
      }
    }

    throw new Error('All retry attempts failed');
  }

  /**
   * 遅延実行
   */
  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

/**
 * データ検証ルール
 */
export class NPBDataValidator {
  static validateGame(game: GameData): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];

    // 必須フィールドのチェック
    if (!game.game_id) errors.push('game_id is required');
    if (!game.date) errors.push('date is required');
    if (!game.away_team) errors.push('away_team is required');
    if (!game.home_team) errors.push('home_team is required');

    // 日付フォーマットのチェック
    if (game.date && !/^\d{4}-\d{2}-\d{2}$/.test(game.date)) {
      errors.push('date must be in YYYY-MM-DD format');
    }

    // スコアの整合性チェック
    if (game.status === 'final') {
      if (game.away_score === undefined || game.home_score === undefined) {
        errors.push('Final games must have scores');
      }
      if (game.away_score !== undefined && game.away_score < 0) {
        errors.push('away_score cannot be negative');
      }
      if (game.home_score !== undefined && game.home_score < 0) {
        errors.push('home_score cannot be negative');
      }
    }

    // チーム名の重複チェック
    if (game.away_team === game.home_team) {
      errors.push('away_team and home_team cannot be the same');
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  static validateGames(games: GameData[]): { validGames: GameData[]; invalidGames: { game: GameData; errors: string[] }[] } {
    const validGames: GameData[] = [];
    const invalidGames: { game: GameData; errors: string[] }[] = [];

    for (const game of games) {
      const validation = this.validateGame(game);
      if (validation.isValid) {
        validGames.push(game);
      } else {
        invalidGames.push({ game, errors: validation.errors });
      }
    }

    return { validGames, invalidGames };
  }
}

// 使用例とヘルパー関数
export async function scrapeNPBSchedule(options: ScrapingOptions): Promise<GameData[]> {
  const scraper = new NPBScraper();
  return await scraper.fetchMonthSchedule(options);
}

export async function getTodayGames(): Promise<GameData[]> {
  const scraper = new NPBScraper();
  return await scraper.fetchTodayGames();
}