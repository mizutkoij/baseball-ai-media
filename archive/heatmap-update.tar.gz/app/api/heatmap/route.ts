import { NextRequest, NextResponse } from 'next/server';
import { Pool } from 'pg';
import { rateLimiters, hashIP, getClientIP } from '@/lib/rate-limiter';

const pool = new Pool({
  connectionString: process.env.DATABASE_URL || process.env.PGURL,
});

// Prometheus メトリクス
let heatmapMetrics: any = null;
try {
  const promClient = require('prom-client');
  heatmapMetrics = {
    requests: new promClient.Counter({
      name: 'heatmap_api_requests_total',
      help: 'Total heatmap API requests',
      labelNames: ['result', 'pitcher_id', 'count_bucket']
    }),
    latency: new promClient.Histogram({
      name: 'heatmap_api_latency_seconds',
      help: 'Heatmap API latency',
      buckets: [0.01, 0.05, 0.1, 0.2, 0.5, 1.0]
    }),
    cacheHits: new promClient.Counter({
      name: 'heatmap_cache_hits_total',
      help: 'Heatmap cache hits',
      labelNames: ['type']
    }),
    dataQuality: new promClient.Gauge({
      name: 'heatmap_quality_score',
      help: 'Heatmap data quality score',
      labelNames: ['pitcher_id', 'count_bucket', 'batter_side']
    })
  };
} catch (e) {
  // Prometheus not available
}

function recordMetrics(result: string, latency?: number, pitcherId?: string, countBucket?: string, qualityScore?: number) {
  if (heatmapMetrics) {
    heatmapMetrics.requests.inc({ 
      result, 
      pitcher_id: pitcherId || 'unknown',
      count_bucket: countBucket || 'unknown'
    });
    
    if (latency !== undefined) {
      heatmapMetrics.latency.observe(latency);
    }
    
    if (qualityScore !== undefined && pitcherId && countBucket) {
      heatmapMetrics.dataQuality.set(
        { pitcher_id: pitcherId, count_bucket: countBucket, batter_side: 'both' },
        qualityScore
      );
    }
  }
}

function recordCacheHit(type: 'hit' | 'miss') {
  if (heatmapMetrics) {
    heatmapMetrics.cacheHits.inc({ type });
  }
}

// キャッシュTTL決定（試合状況に応じて）
function getCacheTTL(pitcherId: string): { maxAge: number; sMaxAge: number } {
  // 実装簡略化：全て5分キャッシュ
  // 本来は試合状況（進行中/終了）に応じて動的調整
  return { maxAge: 300, sMaxAge: 300 }; // 5分
}

// バリデーション
function validateParams(pitcher: string, side: string, countBucket: string): { valid: boolean; error?: string } {
  if (!pitcher || typeof pitcher !== 'string') {
    return { valid: false, error: 'pitcher parameter is required' };
  }
  
  if (!side || !['L', 'R'].includes(side)) {
    return { valid: false, error: 'side must be L or R' };
  }
  
  const validBuckets = ['start', 'ahead', 'behind', 'even', 'two_strike', 'full'];
  if (!countBucket || !validBuckets.includes(countBucket)) {
    return { valid: false, error: `count_bucket must be one of: ${validBuckets.join(', ')}` };
  }
  
  return { valid: true };
}

// GET: ヒートマップデータ取得
export async function GET(request: NextRequest) {
  const startTime = Date.now();
  
  try {
    // レート制限チェック
    const clientIP = getClientIP(request);
    const ipHash = hashIP(clientIP);
    
    const rateLimitResult = rateLimiters.general.check(ipHash);
    if (!rateLimitResult.allowed) {
      recordMetrics('rate_limited', Date.now() - startTime);
      return new Response('Too Many Requests', { 
        status: 429,
        headers: {
          'X-RateLimit-Remaining': rateLimitResult.remainingRequests.toString(),
          'X-RateLimit-Reset': new Date(rateLimitResult.resetTime).toISOString()
        }
      });
    }

    const { searchParams } = new URL(request.url);
    const pitcher = searchParams.get('pitcher');
    const side = searchParams.get('side');
    const countBucket = searchParams.get('countBucket') || searchParams.get('count_bucket');
    
    // パラメータバリデーション
    const validation = validateParams(pitcher!, side!, countBucket!);
    if (!validation.valid) {
      recordMetrics('invalid_params', Date.now() - startTime, pitcher || undefined, countBucket || undefined);
      return NextResponse.json(
        { error: validation.error },
        { status: 400 }
      );
    }

    const client = await pool.connect();
    
    try {
      // データベースからヒートマップ取得
      const result = await client.query(`
        SELECT 
          pitcher_id,
          batter_side,
          count_bucket,
          grid_w,
          grid_h,
          empirical,
          model,
          sample_size,
          quality_score,
          updated_at,
          computed_from_date,
          computed_to_date
        FROM pitch_heatmaps 
        WHERE pitcher_id = $1 
          AND batter_side = $2 
          AND count_bucket = $3
      `, [pitcher, side, countBucket]);

      if (result.rows.length === 0) {
        recordMetrics('not_found', Date.now() - startTime, pitcher, countBucket);
        recordCacheHit('miss');
        
        return NextResponse.json(
          { 
            error: 'Heatmap not found',
            message: `No heatmap data available for pitcher ${pitcher}, batter side ${side}, count ${countBucket}`,
            available: false
          },
          { status: 404 }
        );
      }

      const heatmapData = result.rows[0];
      recordCacheHit('hit');
      
      // レスポンスデータ構築
      const responseData = {
        pitcher_id: heatmapData.pitcher_id,
        batter_side: heatmapData.batter_side,
        count_bucket: heatmapData.count_bucket,
        grid: {
          width: heatmapData.grid_w,
          height: heatmapData.grid_h
        },
        empirical: heatmapData.empirical,
        model: heatmapData.model,
        metadata: {
          sample_size: heatmapData.sample_size,
          quality_score: parseFloat(heatmapData.quality_score || '0'),
          updated_at: heatmapData.updated_at,
          computed_from_date: heatmapData.computed_from_date,
          computed_to_date: heatmapData.computed_to_date
        },
        available: true,
        rateLimitInfo: {
          remaining: rateLimitResult.remainingRequests - 1,
          resetTime: rateLimitResult.resetTime
        }
      };

      // キャッシュヘッダー設定
      const cacheTTL = getCacheTTL(pitcher);
      const response = NextResponse.json(responseData);
      
      response.headers.set('Cache-Control', `public, max-age=${cacheTTL.maxAge}, s-maxage=${cacheTTL.sMaxAge}, stale-while-revalidate=600`);
      response.headers.set('X-Response-Time', `${Date.now() - startTime}ms`);
      response.headers.set('X-Sample-Size', heatmapData.sample_size.toString());
      response.headers.set('X-Quality-Score', (heatmapData.quality_score || '0').toString());
      
      recordMetrics('success', (Date.now() - startTime) / 1000, pitcher, countBucket, parseFloat(heatmapData.quality_score || '0'));
      return response;
      
    } finally {
      client.release();
    }
  } catch (error) {
    recordMetrics('error', (Date.now() - startTime) / 1000);
    console.error('Heatmap API error:', error);
    
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST: ヒートマップ再計算リクエスト（管理用）
export async function POST(request: NextRequest) {
  const startTime = Date.now();
  
  try {
    const { pitcher_id, force = false } = await request.json();
    
    if (!pitcher_id) {
      recordMetrics('invalid_params', Date.now() - startTime);
      return NextResponse.json(
        { error: 'pitcher_id is required' },
        { status: 400 }
      );
    }
    
    // 管理者権限チェック（実装簡略化）
    const authHeader = request.headers.get('authorization');
    if (!authHeader || authHeader !== `Bearer ${process.env.ADMIN_API_KEY}`) {
      recordMetrics('unauthorized', Date.now() - startTime);
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    // バックグラウンドで再計算ジョブを起動
    const { spawn } = require('child_process');
    const child = spawn('npx', ['tsx', 'scripts/heatmap_precompute.ts', `--pitcher=${pitcher_id}`], {
      detached: true,
      stdio: 'ignore'
    });
    child.unref();
    
    recordMetrics('recompute_requested', (Date.now() - startTime) / 1000, pitcher_id);
    
    return NextResponse.json({
      success: true,
      message: `Heatmap recomputation started for pitcher ${pitcher_id}`,
      pitcher_id,
      force,
      estimated_completion: new Date(Date.now() + 2 * 60 * 1000).toISOString() // 2分後予定
    });
    
  } catch (error) {
    recordMetrics('error', (Date.now() - startTime) / 1000);
    console.error('Heatmap recompute error:', error);
    
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// OPTIONS: CORS対応
export async function OPTIONS() {
  return new Response(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  });
}